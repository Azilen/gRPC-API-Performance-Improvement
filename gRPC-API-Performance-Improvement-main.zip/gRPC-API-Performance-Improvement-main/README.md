# AspnetMicroservices

Please install docker and run docker compose command to up all the services.
